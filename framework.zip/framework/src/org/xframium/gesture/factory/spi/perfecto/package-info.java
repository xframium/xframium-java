/**
 * Perfecto based gestures
 *
 * @since 1.0.0
 */

package org.xframium.gesture.factory.spi.perfecto;
