/**
 * The device gesture API for sending user gestures to devices
 *
 * @since 1.0.0
 */

package org.xframium.gesture;
