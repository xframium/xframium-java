/**
 * The device action API is an extension to gestures and allows for specialized device actions to be performed on phones
 *
 * @since 1.0.0
 */

package org.xframium.gesture.device.action;
