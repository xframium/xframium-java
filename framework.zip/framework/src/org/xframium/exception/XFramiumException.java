package org.xframium.exception;

public class XFramiumException extends Exception
{

}
