/**
 * XML Schema definition file for the XML based cloud registry
 *
 * @since 1.0.0
 */


@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.xframium.org/cloudRegistry", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.xframium.device.cloud.xsd;
