insert into PERFECTO_CLOUDS ( NAME, USER_NAME, PASSWORD, HOST_NAME,
                              PROXY_HOST, PROXY_PORT, DESCRIPTION, GRID_INSTANCE )
values ( '', '', '', '', '', '', '', '' );
