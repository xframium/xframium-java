/**
 * SQL scripts for creating database schemas for the cloud registry
 *
 * @since 1.0.0
 */

package org.xframium.device.cloud.sql;
