/**
 * SQL Statement definitions for content management schemas
 *
 * @since 1.0.0
 */

package org.xframium.device.artifact;
