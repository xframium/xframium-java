/**
 * Device interrupts are used to simulate device actions during a test case
 *
 * @since 1.0.0
 */

package org.xframium.device.interrupt;
