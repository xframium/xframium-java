/**
 * SQL scehma definitions for a database backed device data provider
 *
 * @since 1.0.0
 */

package org.xframium.device.data.sql;
