insert into PERFECTO_DEVICES ( NAME, ID, MANUFACTURER, MODEL, OS, OS_VERSION, BROWSER_NAME, BROWSER_VERSION, ACTIVE, AVAILABLE)
values ( '', '', '', '', '', '', '', '', 'Y', 1 );

insert into PERFECTO_DEVICE_CAPABILITIES ( DEVICE_NAME, NAME, CLASS, VALUE )
values ( '', '', '', '' );
