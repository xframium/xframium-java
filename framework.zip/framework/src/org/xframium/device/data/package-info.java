/**
 * Device data providers select devices based off of some criteria.  
 *
 * @since 1.0.0
 */

package org.xframium.device.data;
