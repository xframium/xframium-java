/**
 * XML Schema definitions for device data
 *
 * @since 1.0.0
 */

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.xframium.org/deviceRegistry", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.xframium.device.data.xsd;
