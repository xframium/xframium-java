/**
 * Property adapters allow for additional user defined property to be supplied to the test implementations
 *
 * @since 1.0.0
 */

package org.xframium.device.property;
