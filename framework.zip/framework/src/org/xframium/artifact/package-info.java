/**
 * Artifact productions integration points
 *
 * @since 1.0.0
 */

package org.xframium.artifact;
