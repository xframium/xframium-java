/**
 * Perfecto REST API integrations implementation
 *
 * @since 1.0.0
 */

package org.xframium.integrations.perfectoMobile.rest;
