/**
 * 
 * General BEAN infrastructure for creating JAva beans from XML data or other sources
 *
 * @since 1.0.0
 */

package org.xframium.integrations.rest.bean.factory;
