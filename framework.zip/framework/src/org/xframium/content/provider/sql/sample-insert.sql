insert into PERFECTO_CONTENT( KEY_NAME, VALUE, OFFSET )
values ( '', '', 0 );
