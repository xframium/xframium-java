/**
 * 
 * Root structure of the keyword driven framework
 *
 * @since 1.0.0
 */

package org.xframium.page.keyWord;
