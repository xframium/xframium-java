/**
 * 
 * XML Schema definitions for keyword tests defined as XML
 *
 * @since 1.0.0
 */

package org.xframium.page.keyWord.provider.xsd;
