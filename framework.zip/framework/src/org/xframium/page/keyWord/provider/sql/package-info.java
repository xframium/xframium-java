/**
 * 
 * SQL schemas for database backed keyword definitions
 *
 * @since 1.0.0
 */

package org.xframium.page.keyWord.provider.sql;
