/**
 * 
 * Definitions of individual page elements
 *
 * @since 1.0.0
 */

package org.xframium.page.element;
