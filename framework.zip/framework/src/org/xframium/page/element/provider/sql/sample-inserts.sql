insert into PERFECTO_SITES ( NAME )
values ( '' );

insert into PERFECTO_PAGES ( SITE_NAME, NAME )
values ( '', '' );

insert into PERFECTO_ELEMENTS ( SITE_NAME, PAGE_NAME, NAME, DESCRIPTOR, VALUE, CONTEXT_NAME )
values ( '', '', '', '', '', '' );

