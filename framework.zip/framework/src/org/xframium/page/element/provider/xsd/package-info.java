/**
 * 
 * XML Scehma definitions for page elements in XML
 *
 * @since 1.0.0
 */

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.xframium.org/pageRegistry", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.xframium.page.element.provider.xsd;
