/**
 * 
 * SQL schemas for database backed element providers
 *
 * @since 1.0.0
 */

package org.xframium.page.element.provider.sql;
