insert into PERFECTO_PAGE_DATA_TYPE ( NAME, LOCK_RECORDS )
values ( '', '' );

insert into PERFECTO_PAGE_DATA ( TYPE_NAME, NAME, ACTIVE )
values ( '', '', '' );

insert into PERFECTO_PAGE_DATA_ATTRS ( TYPE_NAME, RECORD_NAME, NAME, VALUE )
values ( '', '', '', '' );

