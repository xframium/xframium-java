/**
 * Integration and XSD support
 *
 * @since 1.0.0
 */
package org.xframium;