/**
 * SQL table definitions for Application Registry schema
 *
 * @since 1.0.1
 */
package org.xframium.application.sql;