insert into PERFECTO_APPLICATIONS( NAME, APP_PACKAGE, BUNDLE_ID, URL, IOS_INSTALL, ANDROID_INSTALL )
values ( '', null, null, null, null, null );

insert into PERFECTO_APP_DEV_CAPABILITIES( APP_NAME, NAME, CLASS, VALUE )
values ( '', '', '', '' );

