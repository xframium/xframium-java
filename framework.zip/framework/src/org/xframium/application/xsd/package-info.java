/**
 * XML Schema Definitions for Application Registry
 *
 * @since 1.0.0
 */

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.xframium.org/applicationRegistry", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.xframium.application.xsd;
